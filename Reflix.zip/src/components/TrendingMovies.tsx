import React from 'react'
import { Star } from 'lucide-react'

const TrendingMovies = () => {
  const movies = [
    { title: "Loetong Kasarung", rating: 7.9, year: 2023, image: "https://images.unsplash.com/photo-1533738363-b7f9aef128ce?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
    { title: "Gajah Langka", rating: 6.0, year: 2023, image: "https://images.unsplash.com/photo-1557050543-4d5f4e07ef46?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
    { title: "Si Kang Satay", rating: 7.1, year: 2023, image: "https://images.unsplash.com/photo-1551024506-0bccd828d307?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
    { title: "Mommy Cat", rating: 7.8, year: 2023, image: "https://images.unsplash.com/photo-1548802673-380ab8ebc7b7?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
    { title: "Hijaber Cantiq", rating: 6.1, year: 2023, image: "https://images.unsplash.com/photo-1572252009286-268acec5ca0a?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
    { title: "Xatra: X", rating: 6.5, year: 2022, image: "https://images.unsplash.com/photo-1536440136628-849c177e76a1?ixlib=rb-1.2.1&auto=format&fit=crop&w=500&q=60" },
  ]

  return (
    <div className="mt-8">
      <h2 className="text-2xl font-bold mb-4 text-white">Trending in Animation</h2>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {movies.map((movie, index) => (
          <div key={index} className="bg-white bg-opacity-20 rounded-lg overflow-hidden shadow-lg hover:bg-opacity-30 transition-colors">
            <img src={movie.image} alt={movie.title} className="w-full h-40 object-cover" />
            <div className="p-2">
              <h3 className="font-bold truncate text-white">{movie.title}</h3>
              <div className="flex items-center justify-between text-sm text-gray-300">
                <div className="flex items-center">
                  <Star size={16} className="text-yellow-400 mr-1" />
                  <span>{movie.rating}</span>
                </div>
                <span>{movie.year}</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default TrendingMovies