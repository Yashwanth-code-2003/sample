import React from 'react'
import { Film, Tv, PlayCircle, Search, User } from 'lucide-react'

const Header = () => {
  return (
    <header className="flex justify-between items-center">
      <div className="flex items-center space-x-2">
        <PlayCircle className="w-8 h-8 text-blue-400" />
        <span className="text-2xl font-bold text-white">Flix.id</span>
      </div>
      <nav className="hidden md:flex space-x-4">
        <button className="flex items-center space-x-1 text-white hover:text-blue-300 transition-colors">
          <Film size={16} />
          <span>Movie</span>
        </button>
        <button className="flex items-center space-x-1 text-white hover:text-blue-300 transition-colors">
          <Tv size={16} />
          <span>Series</span>
        </button>
        <button className="text-white hover:text-blue-300 transition-colors">Originals</button>
      </nav>
      <div className="flex items-center space-x-4">
        <Search className="w-6 h-6 text-white" />
        <div className="flex items-center space-x-2">
          <User className="w-6 h-6 text-white" />
          <span className="hidden md:inline text-white">Sarah J</span>
        </div>
      </div>
    </header>
  )
}

export default Header