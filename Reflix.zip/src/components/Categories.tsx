import React from 'react'
import { Flame, Swords, Heart, Film, Skull, Star, Moon } from 'lucide-react'

const Categories = () => {
  const categories = [
    { name: "Trending", icon: Flame },
    { name: "Action", icon: Swords },
    { name: "Romance", icon: Heart },
    { name: "Animation", icon: Film },
    { name: "Horror", icon: Skull },
    { name: "Special", icon: Star },
    { name: "Drakor", icon: Moon },
  ]

  return (
    <div className="mt-8">
      <div className="flex space-x-4 overflow-x-auto pb-4">
        {categories.map((category, index) => (
          <button key={index} className="flex items-center space-x-2 bg-white bg-opacity-20 text-white px-4 py-2 rounded-full whitespace-nowrap hover:bg-opacity-30 transition-colors">
            <category.icon size={16} />
            <span>{category.name}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

export default Categories