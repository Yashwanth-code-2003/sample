import React from 'react'
import { Play } from 'lucide-react'

const FeaturedMovies = () => {
  const movies = [
    {
      title: "The Adventure of Blue Sword",
      image: "https://images.unsplash.com/photo-1535016120720-40c646be5580?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
    {
      title: "Recalling the journey of Dol's exciting story",
      image: "https://images.unsplash.com/photo-1560109947-543149eceb16?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80",
    },
  ]

  return (
    <div className="grid md:grid-cols-2 gap-4">
      {movies.map((movie, index) => (
        <div key={index} className="relative rounded-lg overflow-hidden shadow-lg">
          <img src={movie.image} alt={movie.title} className="w-full h-64 object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-transparent"></div>
          <div className="absolute bottom-0 left-0 p-4">
            <h2 className="text-xl font-bold mb-2 text-white">{movie.title}</h2>
            <button className="flex items-center space-x-2 bg-blue-500 text-white px-4 py-2 rounded-full hover:bg-blue-600 transition-colors">
              <Play size={16} />
              <span>Let Play Movie</span>
            </button>
          </div>
        </div>
      ))}
    </div>
  )
}

export default FeaturedMovies