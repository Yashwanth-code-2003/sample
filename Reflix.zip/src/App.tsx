import React from 'react'
import Header from './components/Header'
import FeaturedMovies from './components/FeaturedMovies'
import Categories from './components/Categories'
import TrendingMovies from './components/TrendingMovies'

function App() {
  return (
    <div className="min-h-screen w-full p-4 sm:p-6 md:p-8">
      <div className="glassmorphism max-w-7xl mx-auto p-6 sm:p-8">
        <Header />
        <main className="mt-8">
          <FeaturedMovies />
          <Categories />
          <TrendingMovies />
        </main>
      </div>
    </div>
  )
}

export default App